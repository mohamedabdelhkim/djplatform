DEMO PLACEHOLDER
Replace with real assets before production.
